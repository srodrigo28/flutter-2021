# 🤳 Câmera no Flutter
Projeto com exemplos de uso da Câmera e seleção de arquivos do sistema via ImagePicker no Flutter (2.0.5)

## Plugins utilizados

- [Package Camera](https://pub.dev/packages/camera_camera)
- [Package ImagePicker](https://pub.dev/packages/image_picker)

## Instalação

- Clonar o repositório
- `flutter pub get`
- `flutter run` ou Debug via IDE