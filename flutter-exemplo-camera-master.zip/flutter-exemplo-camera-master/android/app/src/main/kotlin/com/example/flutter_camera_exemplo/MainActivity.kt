package com.example.flutter_camera_exemplo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
