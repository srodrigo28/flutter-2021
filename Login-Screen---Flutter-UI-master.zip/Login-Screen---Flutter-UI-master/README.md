# Welcome & Login Screen - Flutter UI

**[Check video tutorial on youtube](https://youtu.be/PpekJXY04fM)**

[Image link](https://unsplash.com/photos/4yzEtTQLdL4)

It's almost a month I'm planing about creat some UI using flutter, but somehow I can't make it. Finally, I made my first UI today and here it is.

![UI](https://github.com/abuanwar072/Login-Screen---Flutter-UI/blob/master/Auth.png?raw=true)

Today we are gonna create those 2 pages, Note that there are a lot of ways to create that two pages using flutter, my way is one of them and I am not an expert in flutter.
